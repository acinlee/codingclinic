#include "ctrls.h"

void CraetCtrls_SFMC(SFMC *sfmc,HWND hWnd,HINSTANCE hInst,RECT rt,HFONT font){
	const int liLMar=25;
	const int liTMar=55;
	const int liBMar=55;
	const int liW=rt.right+liLMar*3;
	const int liH=rt.bottom-liTMar-25;
	
	//sfmc->edShowfm=CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_READONLY|ES_MULTILINE|WS_VSCROLL|WS_HSCROLL,(rt.left+edLMar),(rt.top+edTMar),(edW),(edH),hWnd,(HMENU)SFC_ED_SHOWFM,hInst,NULL);
	sfmc->liShowfm=CreateWindow("listbox",NULL,WS_VISIBLE|WS_CHILD|WS_BORDER|LBS_NOTIFY|WS_VSCROLL|LBS_DISABLENOSCROLL,(rt.left+liLMar),(rt.top+liTMar),(liW),(liH),hWnd,(HMENU)SFC_LI_SHOWFM,hInst,NULL);
	SendMessage(sfmc->liShowfm,WM_SETFONT,(WPARAM)font,(LPARAM)TRUE);
}
void DestroyCtrls_SFMC(SFMC *sfmc){
	DestroyWindow(sfmc->liShowfm);
}
