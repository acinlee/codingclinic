#ifndef _ctrls__h_
#define _ctrls__h_

#include <windows.h>

#define SFC_LI_SHOWFM	100

typedef struct _showformatctrls{
	HWND liShowfm;
}SFMC;

void CraetCtrls_SFMC(SFMC *sfmc,HWND hWnd,HINSTANCE hInst,RECT rt,HFONT font);
void DestroyCtrls_SFMC(SFMC *sfmc);

#endif
