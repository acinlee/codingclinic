#ifndef _format__h_
#define _format__h_

#include <windows.h>

typedef struct _format{
	unsigned char *binary;
	char **fmStr;
	int fileSize;
	int nofLine;
}FORMAT;

void LoadFile(FORMAT *format,char *filename);
BOOL ConversiontoStr(FORMAT *format);
void ShowFormat(FORMAT format,HWND hWnd);
void ComputePercent(FORMAT format,char *per);

#endif
