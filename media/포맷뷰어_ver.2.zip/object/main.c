#include <windows.h>
#include <Doublebuffer.h> 
#include <stdio.h>

#include "format.h"
#include "ctrls.h"

#define WM_SETCTRLS		WM_USER
#define TIMER_CONV		1000

LRESULT CALLBACK MainWndProc(HWND,UINT,WPARAM,LPARAM);

HWND mainWnd;
RECT mainRect,perRect;
HINSTANCE g_hInst;
LPSTR mainWndClass="mainWndClass";

FORMAT format;

SFMC sfmc;

char fontname[]="consolas";
char percent[5];
HFONT hFont;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
		  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;
	
	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=(WNDPROC)MainWndProc;
	WndClass.lpszClassName=mainWndClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	AllocConsole();
	freopen("COIN$", "r", stdin);
	freopen("CONOUT$", "w", stdout);
	freopen("CONOUT$", "w", stderr);

	hWnd=CreateWindow(mainWndClass,mainWndClass,WS_OVERLAPPEDWINDOW,
		  CW_USEDEFAULT,CW_USEDEFAULT,500,500,
		  NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);

	while(GetMessage(&Message,0,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}

	FreeConsole();

	return Message.wParam;
}
	void Draw_MainWnd(HDC hdc,RECT *rt){
		MEMBUF bfm;
		MInitMem(&bfm,hdc,rt);
			TextOut(bfm.MemDC,10,10,percent,lstrlen(percent));
		MShowDeleteMem(&bfm,hdc,rt);
	}
LRESULT CALLBACK MainWndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	switch(iMessage) {
		case WM_CREATE:
			SetRect(&perRect,10,10,50,30);
			hFont=CreateFont(15,0,0,0,0,0,0,0,ANSI_CHARSET,0,0,0,0,fontname);
			LoadFile(&format,"object/test.bmp");
			mainWnd=hWnd;
			SendMessage(hWnd,WM_SIZE,0,0);
			SendMessage(hWnd,WM_SETCTRLS,0,0);
			return 0;
		case WM_SIZE:
			if(wParam!=SIZE_MINIMIZED){
				GetClientRect(hWnd,&mainRect);
			}
			return 0;
		case WM_SETCTRLS:
			DestroyCtrls_SFMC(&sfmc);
			CraetCtrls_SFMC(&sfmc,hWnd,g_hInst,mainRect,hFont);
			return 0;
		case WM_PAINT:
			hdc=BeginPaint(hWnd, &ps);
				Draw_MainWnd(hdc,&mainRect);
			EndPaint(hWnd, &ps);
			return 0;
		case WM_TIMER:
			switch(wParam){
				case TIMER_CONV:
					if(ConversiontoStr(&format)){
						KillTimer(hWnd,TIMER_CONV);
					}
					ShowFormat(format,sfmc.liShowfm);
					ComputePercent(format,percent);
					InvalidateRect(hWnd,&perRect,FALSE);
					break;
			}
			return 0;
		case WM_KEYDOWN:
			switch(wParam){
				case VK_SPACE:
					printf("space\n");
					SetTimer(hWnd,TIMER_CONV,1,NULL);
					break;
			}
			return 0;
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}
