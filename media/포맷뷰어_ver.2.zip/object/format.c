#include "format.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *hFile;

void LoadFile(FORMAT *format,char *filename){
	int fSize;
	
	hFile=fopen(filename,"rb");
	
	if(!hFile){
		fclose(hFile);
		return;
	}
	fseek(hFile,0,SEEK_END);
	fSize=ftell(hFile);
	rewind(hFile);
	
	format->binary=(char *)calloc(fSize,sizeof(char));
	format->fmStr=(char **)calloc(1,sizeof(char *));
	
	fread(format->binary,sizeof(char),fSize,hFile);
	format->fileSize=fSize;
	printf("size: %d  hex:%x\n",format->fileSize,format->fileSize);
	format->nofLine=0;
}
BOOL ConversiontoStr(FORMAT *format){
	int size=format->fileSize;
	int tsize=(size-(size%16))+16;
	int i;
	int a=1;
	static int last=0;
	char *str;
	char tstr[75]={0};
	char start[9]={0};
	char end[18]={0};
	char mid[49]={0};
	char hex[4]={0};
	unsigned char *bin=format->binary;
	unsigned char tbin;
	
	for(i=last;i<last+16;i++){
		tbin=*(bin+i);
		if(i<=size){
			if(i%0x10==0){
				sprintf(start,"%p",i);
			}
			sprintf(hex,(tbin<=0xf)?" 0%x":" %x",tbin);
			end[a++]=(tbin<0x20)?'.':(tbin>127?'.':tbin);
			strcat(mid,hex);
			if((i+1)%0x10==0){
				end[0]=' ';
				strcat(tstr,start);
				strcat(tstr,mid);
				strcat(tstr,end);
				a=1;
			}
		}
		else{
			sprintf(hex,"   ");
			end[a++]=' ';
			strcat(mid,hex);
			if((i+1)%0x10==0){
				end[0]=' ';
				strcat(tstr,start);
				strcat(tstr,mid);
				strcat(tstr,end);
				
				format->fmStr=(char **)realloc(format->fmStr,sizeof(char *)*(format->nofLine+1));
				format->fmStr[format->nofLine]=(char *)calloc(75,sizeof(char));
				strcat(format->fmStr[format->nofLine++],tstr);
				return 1;
			}
		}
	}
	last=i;
	format->fmStr=(char **)realloc(format->fmStr,sizeof(char *)*(format->nofLine+1));
	format->fmStr[format->nofLine]=(char *)calloc(strlen(tstr)+1,sizeof(char));
	sprintf(format->fmStr[format->nofLine++],"%s",tstr);
	return 0;
}
void ShowFormat(FORMAT format,HWND hWnd){
	SendMessage(hWnd,LB_ADDSTRING,0,(LPARAM)format.fmStr[format.nofLine-1]);
}
void ComputePercent(FORMAT format,char *per){
	printf("%lf\n",((((double)format.nofLine*16.0)/(double)format.fileSize)*100));
	sprintf(per,"%d%%\0",(int)((((double)format.nofLine*16.0)/(double)format.fileSize)*100));
}
